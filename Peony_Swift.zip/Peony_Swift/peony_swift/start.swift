import SwiftUI

struct StartView: View {
    var body: some View {
        ZStack {
            // Background image
            Image("bg")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)

            // Foreground elements
            Ellipse()
                .foregroundColor(.clear)
                .frame(width: 50, height: 50)
                .overlay(
                    Image("avatar")
                        .resizable()
                        .scaledToFit()
                )
                .offset(x: 140, y: -364)
                .shadow(
                    color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                )
            Text("Learn Your Risk")
                .font(Font.custom("DM Serif Text", size: 48))
                .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                .offset(x: 2.50, y: -255)
            Text("""
            Being genetic related to a breast cancer patient could increase your risk.

            The sooner you detect the cancer, the higher chance you can get it cured.
            """)
                .font(Font.custom("DM Serif Display", size: 12))
                .foregroundColor(.black)
                .offset(x: 10.50, y: -173)
            Text("Skip this")
                .font(Font.custom("Montserrat", size: 12).weight(.semibold))
                .underline()
                .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                .offset(x: 2, y: -7.50)
            Rectangle()
                .foregroundColor(.clear)
                .frame(width: 248, height: 90)
                .background(Color(red: 0.89, green: 0.36, blue: 0.56).opacity(0.25))
                .cornerRadius(25)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .inset(by: 0.50)
                        .stroke(Color(red: 0.89, green: 0.36, blue: 0.56), lineWidth: 0.50)
                )
                .offset(x: -1, y: -69)
            NavigationLink(destination: Q1View()) {
                Text("Learn your risk in under 2 minutes.")
                    .font(Font.custom("Avenir Next", size: 12).weight(.semibold))
                    .foregroundColor(.black)
                    .offset(x: -1, y: -69)
            }
            Text("Hello, ellenyang098")
                .font(Font.custom("Avenir", size: 20).weight(.heavy))
                .foregroundColor(.black)
                .offset(x: -66.50, y: -363.50)
        }
        .frame(width: 390, height: 844)
    }
}

struct StartView_Previews: PreviewProvider {
    static var previews: some View {
        StartView()
    }
}
