import SwiftUI

struct LoginView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Image("peony_logo")
                    .resizable()
                    .frame(width: 125, height: 125)
                    .offset(x: -0.50, y: -236.50)
                Text("Peony")
                    .font(Font.custom("DM Serif Text", size: 48))
                    .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                    .offset(x: 0, y: -148)
                Text("For breast cancer prognosis, prevention, and patient care.")
                    .font(Font.custom("Montserrat", size: 12).weight(.medium))
                    .foregroundColor(.black)
                    .offset(x: 0.50, y: -91.50)
                Text("Pink stands for Power.")
                    .font(Font.custom("Montserrat", size: 12).weight(.medium))
                    .foregroundColor(Color(red: 0.91, green: 0.25, blue: 0.84))
                    .offset(x: 0, y: -73.50)
                Text("User Name")
                    .font(Font.custom("Inika", size: 20))
                    .foregroundColor(.black)
                    .offset(x: -111, y: -11)
                Text("Password")
                    .font(Font.custom("Inika", size: 20))
                    .foregroundColor(.black)
                    .offset(x: -117.50, y: 94)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 300, height: 45)
                    .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
                    .cornerRadius(5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .inset(by: 0.50)
                            .stroke(Color(red: 0.89, green: 0.36, blue: 0.56), lineWidth: 0.50)
                    )
                    .offset(x: 0, y: 40.50)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 300, height: 45)
                    .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
                    .cornerRadius(5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .inset(by: 0.50)
                            .stroke(Color(red: 0.89, green: 0.36, blue: 0.56), lineWidth: 0.50)
                    )
                    .offset(x: 0, y: 145.50)
                NavigationLink(destination: OnboardView()) {
                    Text("Continue without login")
                        .font(Font.custom("Montserrat", size: 16))
                        .underline()
                        .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                        .offset(x: -1, y: 229)
                }
            }
            .frame(width: 390, height: 844)
            .background(Color(red: 0.97, green: 0.87, blue: 0.95))
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
