import SwiftUI

@main
struct peony_swiftApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()  // Initial view
        }
    }
}
