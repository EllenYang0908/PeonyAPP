import SwiftUI

struct OnboardView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Group {
                    Text("I am a...")
                        .font(Font.custom("Inika", size: 20).weight(.bold))
                        .foregroundColor(.black)
                        .offset(x: -113.50, y: -240)
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 300, height: 75)
                        .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
                        .cornerRadius(25)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.89, green: 0.36, blue: 0.56), lineWidth: 0.50)
                        )
                        .offset(x: 0, y: -157.50)
                        .shadow(
                            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                        )
                    NavigationLink(destination: HomeView()) {
                        Text("Breast Cancer Patient")
                            .font(Font.custom("Montserrat", size: 20).weight(.bold))
                            .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                            .offset(x: -1, y: -157)
                    }
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 300, height: 75)
                        .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
                        .cornerRadius(25)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.61, green: 0.70, blue: 0.46), lineWidth: 0.50)
                        )
                        .offset(x: 0, y: 232.50)
                        .shadow(
                            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                        )
                    Text("Others ")
                        .font(Font.custom("Montserrat", size: 20).weight(.bold))
                        .foregroundColor(Color(red: 0.61, green: 0.70, blue: 0.46))
                        .offset(x: -1, y: 233)
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 300, height: 75)
                        .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
                        .cornerRadius(25)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.61, green: 0.70, blue: 0.46), lineWidth: 0.50)
                        )
                        .offset(x: 0, y: -27.50)
                        .shadow(
                            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                        )
                    NavigationLink(destination: StartView()) {
                                        Text("Family Member of Patient")
                                            .font(Font.custom("Montserrat", size: 20).weight(.bold))
                                            .foregroundColor(Color(red: 0.61, green: 0.70, blue: 0.46))
                                            .offset(x: -1, y: -27)
                                    }
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 300, height: 75)
                        .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
                        .cornerRadius(25)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .inset(by: 0.50)
                                .stroke(Color(red: 0.61, green: 0.70, blue: 0.46), lineWidth: 0.50)
                        )
                        .offset(x: 0, y: 102.50)
                        .shadow(
                            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                        )
                    Text("Medical Professional")
                        .font(Font.custom("Montserrat", size: 20).weight(.bold))
                        .foregroundColor(Color(red: 0.61, green: 0.70, blue: 0.46))
                        .offset(x: -0.50, y: 103)
                    Text("Hello, ellenyang098")
                        .font(Font.custom("Avenir", size: 20).weight(.heavy))
                        .foregroundColor(.black)
                        .offset(x: -66.50, y: -363.50)
                }
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 50, height: 50)
                    .overlay(
                        Image("avatar")
                            .resizable()
                            .scaledToFit()
                    )
                    .offset(x: 140, y: -364)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
            }
            .frame(width: 390, height: 844)
            .background(Color(red: 0.97, green: 0.87, blue: 0.95))
        }
    }
}

struct OnboardView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardView()
    }
}
