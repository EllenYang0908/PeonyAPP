
import Foundation
import SwiftUI

struct ProfileView: View {
  var body: some View {
    ZStack() {
      Group {
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 100, height: 100)
          .overlay(
              Image("avatar")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: 0, y: -231)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 75)
          .background(Color(red: 0.95, green: 0.70, blue: 0.89))
          .offset(x: 0, y: -384.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 175, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .cornerRadius(25)
          .offset(x: -1.50, y: -77.50)
        Text("Edit Profile")
          .font(Font.custom("Inter", size: 12).weight(.bold))
          .foregroundColor(.black)
          .offset(x: 1, y: -77.50)
        Text("ellenyang098")
          .font(Font.custom("Inter", size: 12).weight(.bold))
          .foregroundColor(.black)
          .offset(x: 1, y: -158.50)
        Text("ellenyang@gmail.com")
          .font(Font.custom("Montserrat", size: 12).weight(.light))
          .foregroundColor(.black)
          .offset(x: 1, y: -133.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 45, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .cornerRadius(25)
          .offset(x: -118.50, y: 33.50)
        Text("Settings")
          .font(Font.custom("Avenir Next", size: 16))
          .foregroundColor(.black)
          .offset(x: -46.50, y: 35)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 45, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .cornerRadius(25)
          .offset(x: -118.50, y: 118.50)
        Text("Preferences")
          .font(Font.custom("Avenir Next", size: 16))
          .foregroundColor(.black)
          .offset(x: -33, y: 120)
    
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 45, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .cornerRadius(25)
          .offset(x: -118.50, y: 203.50)
        Text("Logout")
          .font(Font.custom("Avenir Next", size: 16))
          .foregroundColor(Color(red: 0.96, green: 0.40, blue: 0.40))
          .offset(x: -50, y: 205)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 20, height: 19.98)
          .overlay(
              Image("settings")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -118, y: 33.99)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 20, height: 20)
          .overlay(
              Image("preferences")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -118, y: 120)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 18, height: 18)
          .overlay(
              Image("logout")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -118, y: 204)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 300, height: 0)
          .overlay(
            Rectangle()
              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 1)
          )
          .offset(x: 0, y: 76)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 300, height: 0)
          .overlay(
            Rectangle()
              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 1)
          )
          .offset(x: 0, y: 163)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 90)
          .background(Color(red: 0.62, green: 0.68, blue: 0.52))
          .cornerRadius(25)
          .offset(x: 0, y: 380)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 128, height: 58)
          .background(.white)
          .cornerRadius(30)
          .offset(x: 112, y: 377)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 120, height: 50)
          .background(Color(red: 0.61, green: 0.70, blue: 0.46))
          .cornerRadius(25)
          .offset(x: 112, y: 377)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
    
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .offset(x: 92, y: 377)
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .background(Color(red: 1, green: 1, blue: 1).opacity(0))
        .offset(x: -120, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 58, height: 58)
          .background(.white)
          .offset(x: -67, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 58, height: 58)
          .background(.white)
          .offset(x: -135, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 58, height: 58)
          .background(.white)
          .offset(x: 1, y: 376)
        Text("Profile")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .foregroundColor(.white)
          .offset(x: 121.50, y: 378)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 50, height: 50)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .offset(x: -135, y: 377)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .background(Color(red: 1, green: 1, blue: 1).opacity(0))
        .offset(x: -135, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 50, height: 50)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .offset(x: -67, y: 377)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .offset(x: -67, y: 376)
      
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 50, height: 50)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .offset(x: 1, y: 376)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 9, height: 13)
        }
        .padding(
          EdgeInsets(top: 0.50, leading: 2.50, bottom: 0.50, trailing: 2.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: 1, y: 377)
        Text("Profile")
          .font(Font.custom("Avenir Next", size: 20).weight(.bold))
          .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
          .offset(x: 1, y: -378.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("peony_logo")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -151, y: -380)
      }
    }
    .frame(width: 390, height: 844)
    .background(.white);
  }
}

struct ProfileView_Previews: PreviewProvider {
  static var previews: some View {
    ProfileView()
  }
}
