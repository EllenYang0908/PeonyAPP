import SwiftUI

struct HomeView: View {
    var body: some View {
        ZStack {
            Group {
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 390, height: 275)
                    .background(Color(red: 0.97, green: 0.87, blue: 0.95))
                    .cornerRadius(25)
                    .offset(x: 0, y: -284.50)
                NavigationLink(destination: ProfileView()) {
                    Ellipse()
                        .foregroundColor(.clear)
                        .frame(width: 50, height: 50)
                        .overlay(
                            Image("avatar")
                                .resizable()
                                .scaledToFit()
                        )
                        .offset(x: 140, y: -364)
                        .shadow(
                            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                        )
                }
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 390, height: 90)
                    .background(Color(red: 0.62, green: 0.68, blue: 0.52))
                    .cornerRadius(25)
                    .offset(x: 0, y: 380)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
                Text("Hello, ellenyang098")
                    .font(Font.custom("Avenir", size: 20))
                    .foregroundColor(.black)
                    .offset(x: -68, y: -363.50)
                Text("Are You Feeling Powerful Today?")
                    .font(Font.custom("Avenir Next", size: 36).weight(.medium))
                    .foregroundColor(.black)
                    .offset(x: -0.50, y: -271)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 100, height: 35)
                    .background(Color(red: 0.89, green: 0.36, blue: 0.56))
                    .cornerRadius(25)
                    .offset(x: 0, y: -185.50)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 128, height: 58)
                    .background(.white)
                    .cornerRadius(30)
                    .offset(x: -100, y: 377)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 120, height: 50)
                    .background(Color(red: 0.61, green: 0.70, blue: 0.46))
                    .cornerRadius(25)
                    .offset(x: -100, y: 377)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
                NavigationLink(destination: DiscoverView()) {
                                        Text("YES!!")
                                            .font(Font.custom("Avenir Next", size: 12).weight(.medium))
                                            .foregroundColor(.white)
                                            .offset(x: 0, y: -185)
                                    }
                HStack(spacing: 0) {
                    ZStack { }
                        .frame(width: 13, height: 13)
                }
                .padding(0.50)
                .frame(width: 14, height: 14)
                .background(Color(red: 1, green: 1, blue: 1).opacity(0))
                .offset(x: -120, y: 377)
            }
            Group {
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 58, height: 58)
                    .background(.white)
                    .offset(x: 7, y: 377)
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 58, height: 58)
                    .background(.white)
                    .offset(x: 75, y: 377)
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 58, height: 58)
                    .background(.white)
                    .offset(x: 7, y: 377)
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 58, height: 58)
                    .background(.white)
                    .offset(x: 143, y: 376)
                Text("Today ")
                    .font(Font.custom("Avenir Next", size: 12).weight(.medium))
                    .foregroundColor(.white)
                    .offset(x: -90, y: 378)
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 50, height: 50)
                    .background(Color(red: 0.89, green: 0.95, blue: 0.80))
                    .offset(x: 7, y: 377)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
                HStack(spacing: 0) {
                    ZStack { }
                        .frame(width: 13, height: 13)
                }
                .padding(0.50)
                .frame(width: 14, height: 14)
                .offset(x: 7, y: 376)
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 50, height: 50)
                    .background(Color(red: 0.89, green: 0.95, blue: 0.80))
                    .offset(x: 75, y: 377)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
                HStack(spacing: 0) {
                    ZStack { }
                        .frame(width: 9, height: 13)
                }
                .padding(
                    EdgeInsets(top: 0.50, leading: 2.50, bottom: 0.50, trailing: 2.50)
                )
                .frame(width: 14, height: 14)
                .offset(x: 75, y: 377)
                Ellipse()
                    .foregroundColor(.clear)
                    .frame(width: 50, height: 50)
                    .background(Color(red: 0.89, green: 0.95, blue: 0.80))
                    .offset(x: 143, y: 376)
                    .shadow(
                        color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
                    )
            }
            Group {
                HStack(spacing: 0) {
                    ZStack { }
                        .frame(width: 13, height: 13)
                }
                .padding(0.50)
                .frame(width: 14, height: 14)
                .offset(x: 143, y: 377)
                Text("More Blogs >")
                    .font(Font.custom("Montserrat", size: 12))
                    .underline()
                    .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                    .offset(x: 1, y: 312.50)
                Text("Today’s Blog Feed")
                    .font(Font.custom("Avenir", size: 20).weight(.heavy))
                    .foregroundColor(.black)
                    .offset(x: -81.50, y: 84.50)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 332, height: 150)
                    .overlay(
                        Image("blog")
                            .resizable()
                            .scaledToFit()
                    )
                    .cornerRadius(25)
                    .overlay(
                        RoundedRectangle(cornerRadius: 25)
                            .inset(by: 0.50)
                            .stroke(Color(red: 0.83, green: 0.92, blue: 0.69), lineWidth: 0.50)
                    )
                    .offset(x: 0, y: 189)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 330, height: 0)
                    .overlay(
                        Rectangle()
                            .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 0.50)
                    )
                    .offset(x: 1, y: 53)
                Text("Breast Cancer Awareness Month is Coming")
                    .font(Font.custom("Montserrat", size: 12).weight(.bold))
                    .foregroundColor(.black)
                    .offset(x: -30.50, y: 277.50)
                Text("3 min read")
                    .font(Font.custom("Montserrat", size: 8))
                    .foregroundColor(.black)
                    .offset(x: 143.50, y: 279)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 255, height: 45)
                    .background(Color(red: 0.89, green: 0.95, blue: 0.80))
                    .cornerRadius(5)
                    .offset(x: -24.50, y: -66.50)
                Text("Make next appointment with doctor.")
                    .font(Font.custom("Montserrat", size: 12))
                    .foregroundColor(.black)
                    .offset(x: -27.50, y: -66.50)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 45, height: 45)
                    .background(Color(red: 0.95, green: 0.70, blue: 0.89))
                    .cornerRadius(2)
                    .offset(x: 130.50, y: -66.50)
            }
            Group {
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 255, height: 45)
                    .background(Color(red: 0.89, green: 0.95, blue: 0.80))
                    .cornerRadius(5)
                    .offset(x: -24.50, y: -7.50)
                Text("30-minute breath exercise")
                    .font(Font.custom("Montserrat", size: 12))
                    .foregroundColor(.black)
                    .offset(x: -59, y: -7.50)
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 45, height: 45)
                    .background(Color(red: 0.95, green: 0.70, blue: 0.89))
                    .cornerRadius(2)
                    .offset(x: 130.50, y: -7.50)
                NavigationLink(destination: DiscoverView()) {
                    Text("All To-do >")
                        .font(Font.custom("Montserrat", size: 12))
                        .underline()
                        .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                        .offset(x: 1.50, y: 30.50)
                }
                Text("Today’s To-do")
                    .font(Font.custom("Avenir", size: 20).weight(.heavy))
                    .foregroundColor(.black)
                    .offset(x: -102.50, y: -112.50)
            }
        }
        .frame(width: 390, height: 844)
        .background(.white)
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
