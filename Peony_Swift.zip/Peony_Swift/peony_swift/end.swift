import Foundation
import SwiftUI

struct EndView: View {
  var body: some View {
    ZStack() {
      Group {
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 75)
          .background(Color(red: 0.95, green: 0.70, blue: 0.89))
          .offset(x: 0, y: -384.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 280)
          .background(Color(red: 0.97, green: 0.87, blue: 0.95))
          .cornerRadius(25)
          .offset(x: 0, y: -207)
        Text("HIGH.")
          .font(Font.custom("DM Serif Text", size: 24))
          .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
          .offset(x: 67.50, y: -236.50)
        Text("Your risk is")
          .font(Font.custom("DM Serif Text", size: 24))
          .foregroundColor(.black)
          .offset(x: -33, y: -236.50)
        Text("YOUR ACTION PLAN")
          .font(Font.custom("Avenir", size: 16))
          .foregroundColor(.black)
          .offset(x: 0, y: 15)
        Text("Base on the result of the survey,")
          .font(Font.custom("Montserrat", size: 12).weight(.semibold))
          .foregroundColor(.black)
          .offset(x: 0, y: -269.50)
        Text("Don’t worry, keep a healthy lifestyle, and go for professional medical check at least once a year.")
          .font(Font.custom("Montserrat", size: 12))
          .foregroundColor(.black)
          .offset(x: 0, y: -186)
        Text("See More")
          .font(Font.custom("Montserrat", size: 12))
          .underline()
          .foregroundColor(.black)
          .offset(x: -1, y: -126.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 100, height: 0)
          .overlay(
            Rectangle()
              .stroke(Color(red: 0.89, green: 0.36, blue: 0.56), lineWidth: 1.50)
          )
          .offset(x: 0, y: 34)
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .offset(x: 163, y: -384)
   
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 7)
        }
        .padding(
          EdgeInsets(top: 3.50, leading: 0.50, bottom: 3.50, trailing: 0.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: -164, y: -384)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("peony_logo")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: 0, y: -384)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 332, height: 150)
          .overlay(
              Image("exam")
                  .resizable()
                  .scaledToFit()
          )
          .cornerRadius(25)
          .offset(x: 0, y: 132)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 100, height: 35)
          .background(Color(red: 0.89, green: 0.36, blue: 0.56))
          .cornerRadius(25)
          .offset(x: -86, y: 152.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        Text("More Info >")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .foregroundColor(.white)
          .offset(x: -85.50, y: 153)
        Text("Once A Month")
          .font(Font.custom("Montserrat", size: 8))
          .foregroundColor(.black)
          .offset(x: -102.50, y: 124)
        Text("Self Breast Exam")
          .font(Font.custom("Montserrat", size: 20).weight(.bold))
          .foregroundColor(.black)
          .offset(x: -43.50, y: 106)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 332, height: 150)
          .overlay(
              Image("mam")
                  .resizable()
                  .scaledToFit()
          )
          .cornerRadius(25)
          .offset(x: 0, y: 299)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 100, height: 35)
          .background(Color(red: 0.89, green: 0.36, blue: 0.56))
          .cornerRadius(25)
          .offset(x: -86, y: 319.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        Text("More Info >")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .foregroundColor(.white)
          .offset(x: -85.50, y: 320)
      
        Text("Annually")
          .font(Font.custom("Montserrat", size: 8))
          .foregroundColor(.black)
          .offset(x: -114, y: 291)
        Text("Mammogram")
          .font(Font.custom("Montserrat", size: 20).weight(.bold))
          .foregroundColor(.black)
          .offset(x: -61, y: 273)
      }
    }
    .frame(width: 390, height: 844)
    .background(.white);
  }
}

struct EndView_Previews: PreviewProvider {
  static var previews: some View {
    EndView()
  }
}
