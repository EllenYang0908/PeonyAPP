

import Foundation
import SwiftUI

struct Q1View: View {
  var body: some View {
    ZStack() {
      Group {
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 75)
          .background(Color(red: 0.95, green: 0.70, blue: 0.89))
          .offset(x: 0, y: -384.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 20)
          .background(.white)
          .overlay(
            Rectangle()
              .inset(by: 0.50)
              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 0.50)
          )
          .offset(x: 0, y: -337)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 85, height: 20)
          .background(Color(red: 0.89, green: 0.36, blue: 0.56))
          .overlay(
            Rectangle()
              .inset(by: 0.50)
              .stroke(.black, lineWidth: 0.50)
          )
          .offset(x: -152.50, y: -337)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("peony_logo")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: 0, y: -384)
        Text("Do you have blood relative who has/had breast cancer?")
          .font(Font.custom("DM Serif Text", size: 24))
          .foregroundColor(.black)
          .offset(x: 0, y: -181)
        Text("Q1:")
          .font(Font.custom("DM Serif Text", size: 36))
          .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
          .offset(x: -139, y: -249.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 300, height: 75)
          .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
          .cornerRadius(25)
          .overlay(
            RoundedRectangle(cornerRadius: 25)
              .inset(by: 0.50)
              .stroke(Color(red: 0.89, green: 0.36, blue: 0.56), lineWidth: 0.50)
          )
          .offset(x: 0, y: -78.50)
          NavigationLink(destination: EndView()) {
              Text("Yes")
                  .font(Font.custom("DM Serif Display", size: 20))
                  .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
                  .offset(x: -0.50, y: -76.50)
          }
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 300, height: 75)
          .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
          .cornerRadius(25)
          .overlay(
            RoundedRectangle(cornerRadius: 25)
              .inset(by: 0.50)
              .stroke(.black, lineWidth: 0.50)
          )
          .offset(x: 0, y: 51.50)
        Text("No")
          .font(Font.custom("DM Serif Display", size: 20))
          .foregroundColor(.black)
          .offset(x: -1, y: 53.50)
  
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 300, height: 75)
          .background(Color(red: 0.85, green: 0.85, blue: 0.85).opacity(0))
          .cornerRadius(25)
          .overlay(
            RoundedRectangle(cornerRadius: 25)
              .inset(by: 0.50)
              .stroke(.black, lineWidth: 0.50)
          )
          .offset(x: 0, y: 181.50)
        Text("I don’t know")
          .font(Font.custom("DM Serif Display", size: 20))
          .foregroundColor(.black)
          .offset(x: -0.50, y: 183.50)
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 7)
        }
        .padding(
          EdgeInsets(top: 3.50, leading: 0.50, bottom: 3.50, trailing: 0.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: -164, y: -384)
      }
    }
    .frame(width: 390, height: 844)
    .background(Color(red: 0.97, green: 0.87, blue: 0.95));
  }
}

struct Q1View_Previews: PreviewProvider {
  static var previews: some View {
    Q1View()
  }
}
