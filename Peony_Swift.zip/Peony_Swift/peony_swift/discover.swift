
import Foundation
import SwiftUI

struct DiscoverView: View {
  var body: some View {
    ZStack() {
      Group {
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 255, height: 45)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .cornerRadius(5)
          .offset(x: 31.50, y: -252.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 7)
        }
        .padding(
          EdgeInsets(top: 3.50, leading: 0.50, bottom: 3.50, trailing: 0.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: 153, y: -238)
        .rotationEffect(.degrees(180))
        Text("Dr. Smith: Welcome new members!")
          .font(Font.custom("Inter", size: 8))
          .foregroundColor(Color(red: 0.59, green: 0.59, blue: 0.59))
          .offset(x: -18, y: -244)
        Text("Forums")
          .font(Font.custom("Avenir", size: 20).weight(.heavy))
          .foregroundColor(.black)
          .offset(x: -131, y: -309.50)
        Text("Diet during Chemotherapy (132)")
          .font(Font.custom("Inter", size: 10).weight(.bold))
          .foregroundColor(.black)
          .offset(x: -5, y: -260)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 255, height: 45)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .cornerRadius(5)
          .offset(x: 31.50, y: -192.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 7)
        }
        .padding(
          EdgeInsets(top: 3.50, leading: 0.50, bottom: 3.50, trailing: 0.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: 153, y: -175)
        .rotationEffect(.degrees(180))
        Text("Erkk: Hi:)")
          .font(Font.custom("Inter", size: 8))
          .foregroundColor(Color(red: 0.59, green: 0.59, blue: 0.59))
          .offset(x: -67, y: -184)
        Text("Post-surgery Rehabilitation (287)")
          .font(Font.custom("Inter", size: 10).weight(.bold))
          .foregroundColor(.black)
          .offset(x: -2, y: -200)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 255, height: 45)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .cornerRadius(5)
          .offset(x: 31.50, y: -132.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
      
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 7)
        }
        .padding(
          EdgeInsets(top: 3.50, leading: 0.50, bottom: 3.50, trailing: 0.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: 153, y: -115)
        .rotationEffect(.degrees(180))
        Text("Nurse Emily: have you considered think of...")
          .font(Font.custom("Inter", size: 8))
          .foregroundColor(Color(red: 0.59, green: 0.59, blue: 0.59))
          .offset(x: -1.50, y: -124)
        Text("Deal with Emotions During the Fight (476)")
          .font(Font.custom("Inter", size: 10).weight(.bold))
          .foregroundColor(.black)
          .offset(x: 18.50, y: -140)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 75)
          .background(Color(red: 0.95, green: 0.70, blue: 0.89))
          .offset(x: 0, y: -384.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("peony_logo")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -151, y: -380)
        Text("Discover")
          .font(Font.custom("Avenir Next", size: 20).weight(.bold))
          .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
          .offset(x: 1.50, y: -378.50)
        Text("Events")
          .font(Font.custom("Avenir", size: 20).weight(.heavy))
          .foregroundColor(.black)
          .offset(x: -134.50, y: -26.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 332, height: 150)
          .overlay(
              Image("event1")
                  .resizable()
                  .scaledToFit()
          )
          .cornerRadius(25)
          .offset(x: 0, y: 67)
        Text("#Volunteer")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .underline()
          .foregroundColor(.black)
          .offset(x: 98.50, y: 59)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 100, height: 35)
          .background(Color(red: 0.89, green: 0.36, blue: 0.56))
          .cornerRadius(25)
          .offset(x: -86, y: 87.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
      
        Text("More Info >")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .foregroundColor(.white)
          .offset(x: -85.50, y: 88)
        Text("October")
          .font(Font.custom("Montserrat", size: 8))
          .foregroundColor(.black)
          .offset(x: -115.50, y: 59)
        Text("Awareness Month Events")
          .font(Font.custom("Montserrat", size: 20).weight(.bold))
          .foregroundColor(.black)
          .offset(x: 0.50, y: 41)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 332, height: 150)
          .overlay(
              Image("event2")
                  .resizable()
                  .scaledToFit()
          )
          .cornerRadius(25)
          .offset(x: 0, y: 239)
        Text("#Seminar")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .underline()
          .foregroundColor(.black)
          .offset(x: 105.50, y: 231)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 100, height: 35)
          .background(Color(red: 0.89, green: 0.36, blue: 0.56))
          .cornerRadius(25)
          .offset(x: -85, y: 259.50)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        Text("More Info >")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .foregroundColor(.white)
          .offset(x: -84.50, y: 260)
        Text("Monthly Event")
          .font(Font.custom("Montserrat", size: 8))
          .foregroundColor(.black)
          .offset(x: -101.50, y: 231)
        Text("Support Groups")
          .font(Font.custom("Montserrat", size: 20).weight(.bold))
          .foregroundColor(.black)
          .offset(x: -48, y: 213)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 390, height: 90)
          .background(Color(red: 0.62, green: 0.68, blue: 0.52))
          .cornerRadius(25)
          .offset(x: 0, y: 380)
      
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 128, height: 58)
          .background(.white)
          .cornerRadius(30)
          .offset(x: -32, y: 377)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 120, height: 50)
          .background(Color(red: 0.61, green: 0.70, blue: 0.46))
          .cornerRadius(25)
          .offset(x: -32, y: 377)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .offset(x: -57, y: 377)
        Text("Discover")
          .font(Font.custom("Avenir Next", size: 12).weight(.medium))
          .foregroundColor(.white)
          .offset(x: -20.50, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 58, height: 58)
          .background(.white)
          .offset(x: 75, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 58, height: 58)
          .background(.white)
          .offset(x: -136, y: 377)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 58, height: 58)
          .background(.white)
          .offset(x: 143, y: 376)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 50, height: 50)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .offset(x: -136, y: 377)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 50, height: 50)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .offset(x: 75, y: 377)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 9, height: 13)
        }
        .padding(
          EdgeInsets(top: 0.50, leading: 2.50, bottom: 0.50, trailing: 2.50)
        )
        .frame(width: 14, height: 14)
        .offset(x: 75, y: 377)
      
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 50, height: 50)
          .background(Color(red: 0.89, green: 0.95, blue: 0.80))
          .offset(x: 143, y: 376)
          .shadow(
            color: Color(red: 0, green: 0, blue: 0, opacity: 0.25), radius: 4, y: 4
          )
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .offset(x: 143, y: 377)
        HStack(spacing: 0) {
          ZStack() { }
          .frame(width: 13, height: 13)
        }
        .padding(0.50)
        .frame(width: 14, height: 14)
        .background(Color(red: 1, green: 1, blue: 1).opacity(0))
        .offset(x: -136, y: 377)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 330, height: 0)
          .overlay(
            Rectangle()
              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 0.50)
          )
          .offset(x: 0, y: -64)
        Text("All Forums >")
          .font(Font.custom("Montserrat", size: 12))
          .underline()
          .foregroundColor(Color(red: 0.89, green: 0.36, blue: 0.56))
          .offset(x: 2.50, y: -91.50)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 45, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .offset(x: -134.50, y: -251.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("diet")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -135, y: -251)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 45, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .offset(x: -134.50, y: -192.50)
        Ellipse()
          .foregroundColor(.clear)
          .frame(width: 45, height: 45)
          .background(Color(red: 0.83, green: 0.92, blue: 0.69))
          .offset(x: -134.50, y: -132.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("sport")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -135, y: -192)
      
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 30, height: 30)
          .overlay(
              Image("meditate")
                  .resizable()
                  .scaledToFit()
          )
          .offset(x: -135, y: -132)
      }
    }
    .frame(width: 390, height: 844)
    .background(.white);
  }
}

struct DiscoverView_Previews: PreviewProvider {
  static var previews: some View {
    DiscoverView()
  }
}
